protected void processRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    GameBean game = (GameBean) request.getSession(true).getAttribute("gameBean");

    // Obtener la fila y columna desde los parámetros de la URL
    int line = Integer.parseInt(request.getParameter("Line"));
    int col = Integer.parseInt(request.getParameter("Col"));

    // Hacer la jugada del jugador
    game.playPlayerTurn(line, col);

    // Comprobar si hay un ganador
    GamePlayer winner = game.getWinner();

    // Evaluar si el juego ya ha terminado
    switch(winner){
        case NOBODY:
            if(game.hasEmptyCell()){
                game.playComputerTurn();  // El computador hace su jugada
                winner = game.getWinner();
            }
            break;
        case COMPUTER:
            request.setAttribute("winner", "The computer");
            break;
        case USER:
            request.setAttribute("winner", "You");
            break;
    }

    // Si no hay ganador pero ya no hay celdas vacías
    if(winner == GamePlayer.NOBODY && !game.hasEmptyCell()){
        request.setAttribute("winner", "Nobody");
    }

    request.getRequestDispatcher("/game.jsp").forward(request, response);
}

